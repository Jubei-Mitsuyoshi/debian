* This directory contains files and directories used by the Ghost Trap process

* DO NOT DELETE ANY FILE FROM THIS DIRECTORY