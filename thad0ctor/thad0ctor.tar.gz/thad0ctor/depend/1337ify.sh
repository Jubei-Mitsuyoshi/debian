#!/bin/sh
###################################
######## x1337ify Config ##########
## Do not edit outside the ""s! ###
### Do not edit after line 70! ####
###################################
###The last letter after x1337 ####
## represents the letter to edit ##
### i.e. x1337a="@" replaces a ####
######## with the @ symbol#########
###################################
### If you are editing from the ###
## Script press Ctrl+X and then ###
#### Press 'y' to save changes ####
###################################
x1337a="@"
x1337b="b"
x1337c="("
x1337d="d"
x1337e="3"
x1337f="f"
x1337g="g"
x1337h="h"
x1337i="|"
x1337j="j"
x1337k="k"
x1337l="1"
x1337m="m"
x1337n="n"
x1337o="0"
x1337p="p"
x1337q="q"
x1337r="r"
x1337s="5"
x1337t="7"
x1337u="u"
x1337v="v"
x1337w="w"
x1337x="x"
x1337y="y"
x1337z="z"
x1337A="4"
x1337B="|3"
x1337C="("
x1337D="|)"
x1337E="3"
x1337F="F"
x1337G="G"
x1337H="H"
x1337I="|"
x1337J="J"
x1337K="|<"
x1337L="1"
x1337M="M"
x1337N="N"
x1337O="0"
x1337P="P"
x1337Q="Q"
x1337R="|2"
x1337S="5"
x1337T="7"
x1337U="U"
x1337V="\/'"
x1337W="W"
x1337X="X"
x1337Y="Y"
x1337Z="Z"
################################
####Do not edit past here!!!####
###########End Config###########
function f_echobreak () {
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
}
##Begin x1337ify function##
function f_1337 () {
sed -e 's/a/'"$x1337a"'/g' "$infile" > temp1.temp
sed -e 's/b/'"$x1337b"'/g' temp1.temp > temp.temp
sed -e 's/c/'"$x1337c"'/g' temp.temp > temp1.temp
sed -e 's/d/'"$x1337d"'/g' temp1.temp > temp.temp
sed -e 's/e/'"$x1337e"'/g' temp.temp > temp1.temp
sed -e 's/f/'"$x1337f"'/g' temp1.temp > temp.temp
sed -e 's/g/'"$x1337g"'/g' temp.temp > temp1.temp
sed -e 's/h/'"$x1337h"'/g' temp1.temp > temp.temp
sed -e 's/i/'"$x1337i"'/g' temp.temp > temp1.temp
sed -e 's/j/'"$x1337j"'/g' temp1.temp > temp.temp
sed -e 's/k/'"$x1337k"'/g' temp.temp > temp1.temp
sed -e 's/l/'"$x1337l"'/g' temp1.temp > temp.temp
sed -e 's/m/'"$x1337m"'/g' temp.temp > temp1.temp
sed -e 's/n/'"$x1337n"'/g' temp1.temp > temp.temp
sed -e 's/o/'"$x1337o"'/g' temp.temp > temp1.temp
sed -e 's/p/'"$x1337p"'/g' temp1.temp > temp.temp
sed -e 's/q/'"$x1337q"'/g' temp.temp > temp1.temp
sed -e 's/r/'"$x1337r"'/g' temp1.temp > temp.temp
sed -e 's/s/'"$x1337s"'/g' temp.temp > temp1.temp
sed -e 's/t/'"$x1337t"'/g' temp1.temp > temp.temp
sed -e 's/u/'"$x1337u"'/g' temp.temp > temp1.temp
sed -e 's/v/'"$x1337v"'/g' temp1.temp > temp.temp
sed -e 's/w/'"$x1337w"'/g' temp.temp > temp1.temp
sed -e 's/x/'"$x1337x"'/g' temp1.temp > temp.temp
sed -e 's/y/'"$x1337y"'/g' temp.temp > temp1.temp
sed -e 's/z/'"$x1337z"'/g' temp1.temp > temp.temp
sed -e 's/A/'"$x1337A"'/g' temp.temp > temp1.temp
sed -e 's/B/'"$x1337B"'/g' temp1.temp > temp.temp
sed -e 's/C/'"$x1337C"'/g' temp.temp > temp1.temp
sed -e 's/D/'"$x1337D"'/g' temp1.temp > temp.temp
sed -e 's/E/'"$x1337E"'/g' temp.temp > temp1.temp
sed -e 's/F/'"$x1337F"'/g' temp1.temp > temp.temp
sed -e 's/g/'"$x1337g"'/g' temp.temp > temp1.temp
sed -e 's/H/'"$x1337H"'/g' temp1.temp > temp.temp
sed -e 's/I/'"$x1337I"'/g' temp.temp > temp1.temp
sed -e 's/J/'"$x1337J"'/g' temp1.temp > temp.temp
sed -e 's/K/'"$x1337K"'/g' temp.temp > temp1.temp
sed -e 's/L/'"$x1337L"'/g' temp1.temp > temp.temp
sed -e 's/M/'"$x1337M"'/g' temp.temp > temp1.temp
sed -e 's/N/'"$x1337N"'/g' temp1.temp > temp.temp
sed -e 's/O/'"$x1337O"'/g' temp.temp > temp1.temp
sed -e 's/P/'"$x1337P"'/g' temp1.temp > temp.temp
sed -e 's/Q/'"$x1337Q"'/g' temp.temp > temp1.temp
sed -e 's/R/'"$x1337R"'/g' temp1.temp > temp.temp
sed -e 's/S/'"$x1337S"'/g' temp.temp > temp1.temp
sed -e 's/T/'"$x1337T"'/g' temp1.temp > temp.temp
sed -e 's/U/'"$x1337U"'/g' temp.temp > temp1.temp
sed -e 's/V/'"$x1337V"'/g' temp1.temp > temp.temp
sed -e 's/W/'"$x1337W"'/g' temp.temp > temp1.temp
sed -e 's/X/'"$x1337X"'/g' temp1.temp > temp.temp
sed -e 's/Y/'"$x1337Y"'/g' temp.temp > temp1.temp
sed -e 's/Z/'"$x1337Z"'/g' temp1.temp > "$destination/$filename".lst
rm *.temp
}
function f_13371 () {
sed -i -e 's/a/'"$x1337a"'/g' "$infile"
sed -i -e 's/b/'"$x1337b"'/g' "$infile"
sed -i -e 's/c/'"$x1337c"'/g' "$infile"
sed -i -e 's/d/'"$x1337d"'/g' "$infile"
sed -i -e 's/e/'"$x1337e"'/g' "$infile"
sed -i -e 's/f/'"$x1337f"'/g' "$infile"
sed -i -e 's/g/'"$x1337g"'/g' "$infile"
sed -i -e 's/h/'"$x1337h"'/g' "$infile"
sed -i -e 's/i/'"$x1337i"'/g' "$infile"
sed -i -e 's/j/'"$x1337j"'/g' "$infile"
sed -i -e 's/k/'"$x1337k"'/g' "$infile"
sed -i -e 's/l/'"$x1337l"'/g' "$infile"
sed -i -e 's/m/'"$x1337m"'/g' "$infile"
sed -i -e 's/n/'"$x1337n"'/g' "$infile"
sed -i -e 's/o/'"$x1337o"'/g' "$infile"
sed -i -e 's/p/'"$x1337p"'/g' "$infile"
sed -i -e 's/q/'"$x1337q"'/g' "$infile"
sed -i -e 's/r/'"$x1337r"'/g' "$infile"
sed -i -e 's/s/'"$x1337s"'/g' "$infile"
sed -i -e 's/t/'"$x1337t"'/g' "$infile"
sed -i -e 's/u/'"$x1337u"'/g' "$infile"
sed -i -e 's/v/'"$x1337v"'/g' "$infile"
sed -i -e 's/w/'"$x1337w"'/g' "$infile"
sed -i -e 's/x/'"$x1337x"'/g' "$infile"
sed -i -e 's/y/'"$x1337y"'/g' "$infile"
sed -i -e 's/z/'"$x1337z"'/g' "$infile"
sed -i -e 's/A/'"$x1337A"'/g' "$infile"
sed -i -e 's/B/'"$x1337B"'/g' "$infile"
sed -i -e 's/C/'"$x1337C"'/g' "$infile"
sed -i -e 's/D/'"$x1337D"'/g' "$infile"
sed -i -e 's/E/'"$x1337E"'/g' "$infile"
sed -i -e 's/F/'"$x1337F"'/g' "$infile"
sed -i -e 's/g/'"$x1337g"'/g' "$infile"
sed -i -e 's/H/'"$x1337H"'/g' "$infile"
sed -i -e 's/I/'"$x1337I"'/g' "$infile"
sed -i -e 's/J/'"$x1337J"'/g' "$infile"
sed -i -e 's/K/'"$x1337K"'/g' "$infile"
sed -i -e 's/L/'"$x1337L"'/g' "$infile"
sed -i -e 's/M/'"$x1337M"'/g' "$infile"
sed -i -e 's/N/'"$x1337N"'/g' "$infile"
sed -i -e 's/O/'"$x1337O"'/g' "$infile"
sed -i -e 's/P/'"$x1337P"'/g' "$infile"
sed -i -e 's/Q/'"$x1337Q"'/g' "$infile"
sed -i -e 's/R/'"$x1337R"'/g' "$infile"
sed -i -e 's/S/'"$x1337S"'/g' "$infile"
sed -i -e 's/T/'"$x1337T"'/g' "$infile"
sed -i -e 's/U/'"$x1337U"'/g' "$infile"
sed -i -e 's/V/'"$x1337V"'/g' "$infile"
sed -i -e 's/W/'"$x1337W"'/g' "$infile"
sed -i -e 's/X/'"$x1337X"'/g' "$infile"
sed -i -e 's/Y/'"$x1337Y"'/g' "$infile"
sed -i -e 's/Z/'"$x1337Z"'/g' "$infile"
}
function f_1337gtk () {
	f_echobreak
	zenity --info --timeout=4 --text "Please select the word list to 1337ify."
	infile=$(zenity --file-selection --title "Word list to 1337ify")
	zenity --question --title "Edit word list in place?" --text "Would you like to to edit the word list in place (y) or create a new one (n) ?"
	if (( $? == 0 )); then
		zenity --question --title "1337ify word list?" --text "Would you like to go ahead and 1337ify $infile?"
		if (( $? == 0 )); then
			zenity --info --timeout=4 --text "1337ifying $infile..."
			f_13371
			zenity --info --timeout=4 --text "Successfully 1337ified $infile."
			zenity --info --timeout=4 --text "Returning to the main menu..."
		else
			zenity --info --timeout=4 --text "You chose not to 1337ify $infile at this time."
			zenity --info --timeout=4 --text "Returning to the main menu..."
			f_menu
		fi
	else
		filename=$(zenity --entry --title "Output word list" --text "Enter the name of the output word list you would like to create.\n(The file extension .lst will be appended to your selection.)")
		zenity --info --timeout=4 --text "Select the destination where you would like to place $filename.lst"
		destination=$(zenity --file-selection --directory --title "Destination")
		zenity --question --title "Would you like to go ahead and 1337ify $infile\ninto $destination/$filename.lst? (y/n)"
		if (( $? == 0 )); then
			zenity --info --timeout=4 --text "1337ifying $infile..."
			f_1337
			if [ -e "$destination/$filename".lst ]; then
				zenity --info --timeout=4 --text "$filename.lst exists in directory: $destination"
				zenity --info --timeout=4 --text "Successfully 1337ified $infile into: $destination/$filename.lst"
				zenity --info --timeout=4 --text "Returning to the main menu..."
			else
				zenity --info --timeout=4 --text "$filename does not exist in directory: $destination"
				zenity --info --timeout=4 --text "Let's try this again..."
				f_1337check
			fi
			zenity --info --timeout=4 --text "Returning to the main menu..."
		else
			zenity --info --timeout=4 --text "You chose not to 1337ify $infile at this time."
			zenity --info --timeout=4 --text "Returning to the main menu..."
		fi
	fi
}
function f_1337cli () {
	f_echobreak
	echo "Please enter the full name and path of the word list to 1337ify."
	echo "(e.x. /root/Desktop/wordlist.lst)"
	echo
	read infile
	if [ -e $infile ]; then
		echo
		echo "$infile exists."
		echo
		sleep 3
	else
		echo
		echo "$infile does not exist."
		echo
		sleep 1
		echo "Let's try this again..."
		sleep 1
		f_1337check
	fi
	echo
	echo "Would you like to to edit the word list in place(y) or create a new one?(n)(y/n)"
	echo
	read edit
	if [ "$edit" = "y" ]; then
		echo
		echo "Would you like to go ahead and 1337ify $infile? (y/n)"
		echo
		read create
		if [ "$create" = "y" ]; then
			echo
			echo "1337ifying $infile..."
			echo
			f_13371
			echo
			echo "Successfully 1337ified $infile."
			echo
			sleep 2
			echo
			echo "Returning to the main menu..."
			echo
			sleep 3
		elif [ "$create" = "n" ]; then
			echo
			echo "You chose not to 1337ify $infile at this time."
			echo
			sleep 2
			echo
			echo "Returning to the main menu..."
			echo
			sleep 3
		else
			echo 
			echo "You did not enter a correct answer."
			echo
			sleep 2
			echo
			echo "Starting over..."
			echo
			sleep 3
			f_1337check
		fi
	elif [ "$edit" = "n" ]; then
		echo
		echo
		echo "Enter the name of the output word list you would like to create?"
		echo "(The file extension .lst will be appended to your selection.)"
		echo
		read filename
		echo
		echo "Enter the destination where you would like to place $filename.lst"
		echo "(e.x. /root/Desktop)"
		echo
		read destination
		while [ ! -d "$destination" ]
		do
			echo
			echo "Directory cannot be found or does not exist"
			echo
			sleep 1
			echo "Would you like to create a folder for the directory you selected? (y/n)"
			read newdir
			if [ $newdir = "y" ]; then
				mkdir "$destination"
				while [ ! -d "$destination" ]
				do
					echo "Folder: $destination still cannot be found, starting over..."
					sleep 2
					f_1337check
				done
			else	
				sleep 1
				echo "Where would you like the output word list to be placed?"
				echo "(e.x. /root/Desktop/)"
				read destination
			fi
		done
		echo
		echo "Would you like to go ahead and 1337ify $infile"
		echo "into $destination/$filename.lst? (y/n)"
		echo
		read create
		if [ "$create" = "y" ]; then
			echo
			echo "1337ifying $infile..."
			echo
			f_1337
			echo
			if [ -e "$destination/$filename".lst ]; then
				echo
				echo "$filename.lst exists in directory: $destination"
				echo
				sleep 2
				echo "Successfully 1337ified $infile into: $destination/$filename.lst"
				echo
				sleep 3
				echo "Returning to the main menu..."
				echo
				sleep 2
			else
				echo
				echo "$filename does not exist in directory: $destination"
				echo
				sleep 1
				echo "Let's try this again..."
				sleep 1
				f_1337check
			fi
		elif [ "$create" = "n" ]; then
			echo
			echo "You chose not to 1337ify $infile at this time."
			echo
			sleep 2
			echo
			echo "Returning to the main menu..."
			echo
			sleep 3
		else
			echo 
			echo "You did not enter a correct answer."
			echo
			sleep 2
			echo
			echo "Starting over..."
			echo
			sleep 3
			f_1337check
		fi
	else
		echo
		echo "You did not input a correct answer."
		echo
		sleep 2
		echo "Starting over..."
		echo
		sleep 3
		f_1337check
	fi
}
function f_1337check () {
if [ "$GTK" = "y" ]; then
	f_1337gtk
else
	f_1337cli
fi
}
gtk=$(echo | cat depend/tempsettings.sh)
echo $gtk
sleep 2
GTK=$gtk
echo "GTK = $GTK"
sleep 2
f_1337check
