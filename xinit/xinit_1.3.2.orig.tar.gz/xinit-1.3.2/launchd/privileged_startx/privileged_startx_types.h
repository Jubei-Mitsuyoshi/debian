#ifndef _PRIV_STARTX_TYPES_H_
#define _PRIV_STARTX_TYPES_H_

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#define BOOTSTRAP_NAME BUNDLE_ID_PREFIX".privileged_startx"

#endif
