/* Public domain. */

#ifndef ALLOC_H
#define ALLOC_H

extern /*@null@*//*@out@*/char *alloc();
extern void alloc_free();
extern int alloc_re();

#endif
