#define RUNIT "/sbin/runit"
#define STOPIT "/etc/runit/stopit"
#define REBOOT "/etc/runit/reboot"
#define CTRLALTDEL "/etc/runit/ctrlaltdel"
