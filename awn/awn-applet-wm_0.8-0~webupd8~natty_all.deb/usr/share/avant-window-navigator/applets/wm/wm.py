#!/usr/bin/python
#
#       AWN Window Manager Python Applet
#
#       Copyright (c) 2008, 2009, 2010 Bryan Blunt <bryan@blunt.me.uk>
#       Based on AWN Test Python Applet Copyright (c) 2007 Neil Jagdish Patel
#
#       This library is free software; you can redistribute it and/or
#       modify it under the terms of the GNU Lesser General Public
#       License as published by the Free Software Foundation; either
#       version 2 of the License, or (at your option) any later version.
#
#       This library is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#       Lesser General Public License for more details.
#
#       You should have received a copy of the GNU Lesser General Public
#       License along with this library; if not, write to the
#       Free Software Foundation, Inc., 59 Temple Place - Suite 330,
#       Boston, MA 02111-1307, USA.

import sys
import os
import gtk
from gtk import gdk
import pygtk

import awn
import wnck
import math
from awn.extras import awnlib
from desktopagnostic import config

applet_name = "Window Manager"
applet_version = "0.8"
applet_description = "An applet to manipulate windows"
applet_logo = os.path.join(os.path.dirname(__file__), "tilesbs.svg")

func_mapping = ["show_desktop", 
           "max_all", 
           "max_active", 
           "min_active", 
           "close_active", 
           "tile_sidebyside", 
           "tile_stacked", 
           "tile",
           "no_action"]

name_mapping = ["Show desktop", 
                "Maximise all", 
                "Maximise %s", 
                "Minimise %s", 
                "Close %s", 
                "Tile - side by side", 
                "Tile - stacked", 
                "Tile",
                "No action"]

title_mapping = [False,
                 False,
                 True,
                 True,
                 True,
                 False,
                 False,
                 False,
                 False]

MAX_BUTTONS = 2

class TileApplet(awn.AppletSimple):

    def __init__(self, uid, panel_id):
        
        awn.AppletSimple.__init__(self, "wm", uid, panel_id)
        self.button_funcs = [0 ,0]
        self.window_callback_id = None
        
        self.get_config()
        self.prefs_dialog = self.setup_dialog_settings()
        self.setup_context_menu()

        self.connect("button-press-event", self.button_press)
        self.connect("context-menu-popup", self.menu_popup)
        s = wnck.screen_get_default()
        s.connect("active-window-changed", self.active_window_change)   
            
    def get_config(self):
        #create default settings
        self.client = awn.config_get_default_for_applet(self)
        self.button_names = self.client.get_list(config.GROUP_DEFAULT, "buttons")
        self.tile_all_windows = self.client.get_bool(config.GROUP_DEFAULT, "tile_all_windows")
        if self.button_names == []:
            self.button_names = ["tile_sidebyside","show_desktop"]
            self.client.set_list(config.GROUP_DEFAULT,"buttons", self.button_names)
        self.button_funcs[0] = TileApplet.__dict__[self.button_names[0]]
        self.button_funcs[1] = TileApplet.__dict__[self.button_names[1]]
        self.set_tooltip()

    def setup_dialog_settings(self):
        window = gtk.Window()
        window.set_type_hint(gtk.gdk.WINDOW_TYPE_HINT_DIALOG)
        vbox = gtk.VBox()
        self.combobox = []
  
        for i in range(0,MAX_BUTTONS):
            if i == 0:
                vbox.add(gtk.Label("Left button behaviour"))
            else:
                vbox.add(gtk.Label("Middle button behaviour"))
            
            self.combobox.append(gtk.combo_box_new_text())
            for j, item in enumerate(name_mapping):
                if title_mapping[j]:
                    self.combobox[i].append_text(item % "active window")
                else:
                    self.combobox[i].append_text(item)
            self.combobox[i].connect("changed", self.changesettings, i)
            vbox.add(self.combobox[i])
    
            model = self.combobox[i].get_model()
            active = self.combobox[i].set_active(self.get_index(i))     
        
        self.tile_all_windows_checkbox = gtk.CheckButton("Tile all windows (including dialogs, toolbars, screenlets etc)")
        self.tile_all_windows_checkbox.set_active(self.tile_all_windows)
        self.tile_all_windows_checkbox.connect("toggled", self.change_tile_all_windows)
        vbox.add(self.tile_all_windows_checkbox)
        
        vbox.show_all()
        window.add(vbox)
        
        def hide_window(window, event):
            window.hide()
            return True

        window.connect('delete-event', hide_window)
                
        return window    

    def setup_context_menu(self):
        # Setup right click menu
        items = \
            [('show_desk', 'Show desktop', gtk.gdk.CONTROL_MASK, ord('d'), ''), 
            ('tile-vert', 'Tile - side by side', gtk.gdk.CONTROL_MASK, ord('s'), ''), 
            ('tile-horiz', 'Tile - stacked', gtk.gdk.CONTROL_MASK, ord('k'), ''), 
            ('tile-tile', 'Tile', gtk.gdk.CONTROL_MASK, ord('t'), ''), 
            ('w-close', 'Close', gtk.gdk.CONTROL_MASK, ord('c'), ''), 
            ('w-minimise', 'Minimise', gtk.gdk.CONTROL_MASK, ord('l'), ''), 
            ('w-maximise', 'Maximise', gtk.gdk.CONTROL_MASK, ord('a'), ''), 
            ]

        gtk.stock_add(items)

        factory = gtk.IconFactory()
        factory.add_default()

        icon_theme = gtk.icon_theme_get_default()
        pixbuf = icon_theme.load_icon("desktop", 48, 0)
        icon_set = gtk.IconSet(pixbuf)
        factory.add('show_desk', icon_set)

        pixbuf = icon_theme.load_icon("add", 48, 0)
        icon_set = gtk.IconSet(pixbuf)
        factory.add('w-maximise', icon_set)
        
        pixbuf = icon_theme.load_icon("remove", 48, 0)
        icon_set = gtk.IconSet(pixbuf)
        factory.add('w-minimise', icon_set)
        
        pixbuf = icon_theme.load_icon("gtk-close", 48, 0)
        icon_set = gtk.IconSet(pixbuf)
        factory.add('w-close', icon_set)

        pixbuf = gtk.gdk.pixbuf_new_from_file(os.path.join(os.path.dirname(__file__), "icons/tilesbs.svg"))
        icon_set = gtk.IconSet(pixbuf)
        factory.add('tile-vert', icon_set)

        pixbuf = gtk.gdk.pixbuf_new_from_file(os.path.join(os.path.dirname(__file__), "icons/tilestacked.svg"))
        icon_set = gtk.IconSet(pixbuf)
        factory.add('tile-horiz', icon_set)

        pixbuf = gtk.gdk.pixbuf_new_from_file(os.path.join(os.path.dirname(__file__), "icons/tiletile.svg"))
        icon_set = gtk.IconSet(pixbuf)
        factory.add('tile-tile', icon_set)
            
        self.context_menu = self.create_default_menu()

        self.context_menu.insert(gtk.SeparatorMenuItem(), len(self.context_menu) - 1)
        
        button = gtk.ImageMenuItem("show_desk")
        button.connect("activate", self.show_desktop)
        self.context_menu.insert(button, len(self.context_menu) - 1)

        button = gtk.MenuItem(label="Maximise all windows")
        button.connect("activate", self.max_all)
        self.context_menu.insert(button, len(self.context_menu) - 1)

        button = gtk.ImageMenuItem("w-maximise")
        button.connect("activate", self.max_active)
        self.context_menu.insert(button, len(self.context_menu) - 1)
        
        button = gtk.ImageMenuItem("w-minimise")
        button.connect("activate", self.min_active)
        self.context_menu.insert(button, len(self.context_menu) - 1)
        
        button = gtk.ImageMenuItem("w-close")
        button.connect("activate", self.close_active)
        self.context_menu.insert(button, len(self.context_menu) - 1)

        button = gtk.ImageMenuItem("tile-vert")
        button.connect("activate", self.tile_sidebyside)
        self.context_menu.insert(button, len(self.context_menu) - 1)

        button = gtk.ImageMenuItem("tile-horiz")
        button.connect("activate", self.tile_stacked)
        self.context_menu.insert(button, len(self.context_menu) - 1)

        button = gtk.ImageMenuItem("tile-tile")
        button.connect("activate", self.tile)
        self.context_menu.insert(button, len(self.context_menu) - 1)             
       
        self.context_menu.insert(gtk.SeparatorMenuItem(), len(self.context_menu) - 1)
        
        self.prefs = gtk.ImageMenuItem(gtk.STOCK_PREFERENCES)
        self.prefs.connect("activate", self.show_prefs)
        self.context_menu.append(self.prefs)
        
        self.about = gtk.ImageMenuItem(gtk.STOCK_ABOUT)
        self.about.connect("activate", self.show_about)
        self.context_menu.append(self.about)
                
        self.context_menu.show_all()  
    
    def show_prefs(self, x):
        self.prefs_dialog.show()    

    def show_about(self, x):
        about = gtk.AboutDialog()
        awn_icon = self.get_icon()
        about.set_logo(awn_icon.get_icon_at_size(48))
        about.set_icon(awn_icon.get_icon_at_size(64))
        about.set_name("Window Manager Applet for AWN")
        about.set_copyright("Copyright (c) 2010 Bryan Blunt <bryan@blun.to>")
        about.set_authors(["Bryan Blunt <bryan@blun.to>"])
        about.set_comments("Manages windows")
        about.set_license("This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA.")
        about.set_wrap_license(True)
        about.run()
        about.destroy()
    
    def button_press(self, widget, event):
        if event.button <= MAX_BUTTONS and event.button != 3:
            self.button_funcs[event.button - 1](self)
                
    def menu_popup(self, widget, event):
        self.context_menu.popup(None, None, None, event.button, event.time)    
    
    def changesettings(self, wdg, button_number):

        model = self.combobox[button_number].get_model()
        active = self.combobox[button_number].get_active()
        self.button_funcs[button_number] = TileApplet.__dict__[func_mapping[active]]
        
        templist = self.button_names
        templist[button_number] = func_mapping[active]
        self.button_names = templist
        self.client.set_list(config.GROUP_DEFAULT,"buttons", self.button_names)
        self.set_tooltip()
                
        if button_number == 0:
            size = self.get_size() 
            if active == 0:
                self.set_icon_name('desktop')  
            elif active == 1:
                self.set_icon_name('add')   
            elif active == 2:
                self.set_icon_name('add')   
            elif active == 3:
                self.set_icon_name('remove') 
            elif active == 4:
                self.set_icon_name('gtk-close') 
            elif active == 5:
                self.set_icon_name("tilesbs")                  
            elif active == 6:
                self.set_icon_name("tilestacked")
            elif active == 7:
                self.set_icon_name("tiletile")        

    def change_tile_all_windows(self, params):
        self.tile_all_windows = self.tile_all_windows_checkbox.get_active()
        print self.tile_all_windows
        self.client.set_bool(config.GROUP_DEFAULT,"tile_all_windows", self.tile_all_windows_checkbox.get_active())
    
    def get_index(self, button_number):
        for i, item in enumerate(func_mapping):
            if self.button_names[button_number] == item:
                return i 

    def set_tooltip(self):
        i = self.get_index(0)      
        if title_mapping[i]:
            try:
                wname = wnck.screen_get_default().get_active_window().get_name()
            except:
                wname = "(no active window)"
            self.set_tooltip_text(name_mapping[i] % wname)
        else:
            self.set_tooltip_text(name_mapping[i])

    def active_window_change(self, scr, wnd):
        self.set_tooltip()
        if self.window_callback_id:
            wnd.disconnect(self.window_callback_id)
        try:
            wname = wnck.screen_get_default().get_active_window()
            self.window_callback_id = wname.connect("name-changed", self.window_name_change)
        except:
            self.window_callback_id = None
            
    def window_name_change(self, wnd):
        self.set_tooltip()            

    def show_desktop(self, widget=None):
        s = wnck.screen_get_default()
        s.toggle_showing_desktop(not s.get_showing_desktop())
        
    def max_all(self, widget=None):
        s = wnck.screen_get_default()
        for window in s.get_windows():
            window.maximize()
            
    def max_active(self, widget=None):
        s = wnck.screen_get_default()
        if s.get_active_window().is_maximized():
            s.get_active_window().unmaximize()
        else:
            s.get_active_window().maximize()
            
    def min_active(self, widget=None):
        s = wnck.screen_get_default()
        s.get_active_window().minimize()

    def no_action(self, widget=None):
        pass
            
    def close_active(self, widget=None):
        s = wnck.screen_get_default()
        s.get_active_window().close(0)

    def tile_sidebyside(self, widget=None):
        self.tile_pattern("vert")
        
    def tile_stacked(self, widget=None):
        self.tile_pattern("horiz")
        
    def tile(self, widget=None):
        self.tile_pattern("tile")

    def tile_pattern(self, tiling_method):
        s = wnck.screen_get_default()
        s.force_update()
        if self.tile_all_windows:
            print "tile_all"
            li = [i for i in s.get_windows() if 
                    #wnck.WINDOW_ACTION_MOVE & i.get_actions() == wnck.WINDOW_ACTION_MOVE and
                    1 & i.get_actions() == 1 and
                    i.is_minimized() == False and
                    i.is_in_viewport(s.get_active_workspace()) == True]
        else:
            li = [i for i in s.get_windows() if 
                    i.get_window_type() == wnck.WINDOW_NORMAL and
                    #wnck.WINDOW_ACTION_MOVE & i.get_actions() == wnck.WINDOW_ACTION_MOVE and
                    1 & i.get_actions() == 1 and
                    i.is_minimized() == False and
                    i.is_in_viewport(s.get_active_workspace()) == True]

        if tiling_method == "vert":

            pattern = [len(li)]

        elif tiling_method == "horiz":

            pattern = [1] * len(li)

        elif tiling_method == "tile":
            pattern = []
            t1 = int(math.sqrt(len(li)))
            if len(li) > t1 * (t1 + 1):
                rows = t1 + 1
            else:
                rows = t1

            winds = len(li)

            for loop1 in range(0, rows):
                if t1 * (rows - loop1) == winds:
                    cols = t1
                else:
                    cols = t1 + 1
                winds -= cols
                pattern.append(cols)

        self.general_tile(pattern, li)

    def general_tile(self, pattern, windowlist):
        w = gtk.gdk.get_default_root_window()
        p = gtk.gdk.atom_intern('_NET_WORKAREA')
        left, top, width, size = w.property_get(p)[2][0:4]

        if windowlist == []:
            pass
        else:
            tilesize = size / len(pattern)
            #flags = wnck.WINDOW_CHANGE_X | wnck.WINDOW_CHANGE_Y | wnck.WINDOW_CHANGE_WIDTH | wnck.WINDOW_CHANGE_size
            flags = 1 | 2 | 4 | 8
            for i in pattern:
                tilewidth = width / i
                for j in range(0, i):
                    wind = windowlist.pop()
                    wind.unmaximize()
                    wind.set_geometry(wnck.WINDOW_GRAVITY_STATIC, flags, left + j * tilewidth, top, tilewidth, tilesize)
                top += tilesize

if __name__ == "__main__":
        
    awn.init(sys.argv[1:])
    applet = TileApplet(awn.uid, awn.panel_id)    
    awn.embed_applet(applet)
    applet.show_all()      
    gtk.main()
