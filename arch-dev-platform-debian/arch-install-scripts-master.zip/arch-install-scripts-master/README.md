# Arch Install Scripts

This is a small suite of scripts aimed at automating some meanial
tasks when installing [Arch Linux](https://www.archlinux.org).

## License

See COPYING for details.
